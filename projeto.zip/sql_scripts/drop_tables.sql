DROP TABLE IF EXISTS forum;               -- check
DROP TABLE IF EXISTS quantity;            -- check
DROP TABLE IF EXISTS to_order;            -- check
DROP TABLE IF EXISTS administrator;       -- check
DROP TABLE IF EXISTS rating;              -- check
DROP TABLE IF EXISTS product;             -- check
DROP TABLE IF EXISTS buyer;               -- check
DROP TABLE IF EXISTS seller;              -- check
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS customer;            -- check
