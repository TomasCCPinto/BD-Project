

SUCCESS_CODE    = 200
GET_ERROR_CODE  = 400   # bad request by part of user 
POST_ERROR_CODE = 500   # internel server/api error
